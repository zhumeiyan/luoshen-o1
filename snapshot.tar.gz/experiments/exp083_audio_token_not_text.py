# -*- coding: utf-8 -*-
"""
exp083: 音频 token 还是文本 token —— 顶级开源语音模型 12.5Hz 收敛点的可测检验

【现象来源】读开源架构（不抄代码，只读它运行时涌现的收敛点）
  Qwen3-Omni : AuT 编码器 -> 12.5Hz 连续 audio hidden states，与 text token 拼接进同一 Thinker
  Moshi/Mimi : 24kHz -> 12.5Hz x 8 码本离散 codec token，双流 + inner monologue
  Kimi-Audio : Whisper encoder 内插 VQ -> 12.5Hz 离散语义 token + 连续声学向量，双头
  GLM-4-Voice: Whisper encoder 插 VQ 层 -> 离散 token
  四家独立收敛到 12.5 Hz（80ms/token）；文本 token 约 3-4 Hz。

【三个可证伪问题】
  H1 同一句话、不同韵律 -> 文本 token 完全相同，音频 token 不同（可量化）
  H2 存在任务：音频 token 可解、文本 token 不可解
  H3 12.5Hz 是信息意义上的最优，还是工程妥协（延迟/带宽）？

【v2 修正（本轮我自己抓到的 bug）】
  v1 全帧率 acc=1.0000 饱和 —— 因为我把「序列长度」放进了特征，
  而四类时长不同（0.94/1.39/0.79/1.62s），分类器靠长度一击必杀。
  v2：所有序列重采样到固定 16 帧 -> 长度线索彻底消除；并加 SNR 梯度制造难度。
"""
import os, sys, json, math
import numpy as np
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
SR = 16000
NFIX = 16          # 固定帧数：消除长度线索
KM = 16            # 码本大小（小码本，配合 one-hot 位置特征）

SYLLABLES = [(700, 1220, 2600), (400, 2100, 2900), (530, 1840, 2480),
             (640, 1190, 2390), (480, 1350, 2650)]
PROSODY = {
    'happy': dict(f0=240.0, rng=90.0, dur=0.16, amp=1.00, drift=+0.25),
    'calm':  dict(f0=155.0, rng=25.0, dur=0.24, amp=0.55, drift=+0.00),
    'angry': dict(f0=115.0, rng=70.0, dur=0.13, amp=1.15, drift=-0.10),
    'tired': dict(f0=140.0, rng=20.0, dur=0.30, amp=0.40, drift=-0.35),
}
LABELS = ['happy', 'calm', 'angry', 'tired']

def synth(style, seed, target_len=19200):
    p = PROSODY[style]; rng = np.random.default_rng(seed)
    dur = p['dur'] * (1.0 + 0.05 * rng.standard_normal())
    out = []
    for i, (F1, F2, F3) in enumerate(SYLLABLES):
        n = int(SR * dur); t = np.arange(n) / SR
        prog = i / max(1, len(SYLLABLES) - 1)
        f0 = p['f0'] * (1.0 + p['drift'] * prog) \
             + p['rng'] * np.sin(2 * np.pi * 1.7 * t + prog * 3.0) \
             + 6.0 * rng.standard_normal()
        f0 = np.clip(f0, 60.0, 400.0)
        ph = 2 * np.pi * np.cumsum(f0) / SR
        sig = np.zeros(n)
        for k in range(1, 26):
            fk = k * f0; env = 0.0
            for F, B, w in ((F1, 90, 1.0), (F2, 130, 0.7), (F3, 200, 0.4)):
                env += w / (1.0 + ((fk - F) / B) ** 2)
            sig += env / k ** 0.9 * np.sin(ph * k)
        win = np.sin(np.pi * np.linspace(0, 1, n)) ** 0.6
        out.append(sig * win * p['amp']); out.append(np.zeros(int(SR * 0.03)))
    y = np.concatenate(out)
    y = y / (np.max(np.abs(y)) + 1e-9) * 0.85
    return y.astype(np.float64)

def mel_fb(n_mels=40, n_fft=1024):
    hz2mel = lambda f: 2595.0 * np.log10(1.0 + f / 700.0)
    mel2hz = lambda m: 700.0 * (10 ** (m / 2595.0) - 1.0)
    pts = np.linspace(hz2mel(50.0), hz2mel(7000.0), n_mels + 2)
    bins = np.floor((n_fft + 1) * mel2hz(pts) / SR).astype(int)
    fb = np.zeros((n_mels, n_fft // 2 + 1))
    for m in range(n_mels):
        l, c, r = bins[m], bins[m + 1], bins[m + 2]
        if c == l: c += 1
        if r == c: r = c + 1
        for i in range(l, min(c, fb.shape[1])): fb[m, i] = (i - l) / (c - l)
        for i in range(min(c, fb.shape[1]), min(r, fb.shape[1])): fb[m, i] = (r - i) / (r - c)
    return fb
_FB = mel_fb()

def stft_mel(y, hop=160, n_fft=1024):
    n = len(y); pad = np.zeros(n + n_fft); pad[:n] = y
    nfr = max(1, 1 + (n - n_fft) // hop)
    idx = np.arange(n_fft)[None, :] + hop * np.arange(nfr)[:, None]
    S = np.abs(np.fft.rfft(pad[idx] * np.hanning(n_fft)[None, :], axis=1)) ** 2
    return np.log(_FB @ S.T + 1e-8).T                      # 100Hz 基准帧率

def resample_frames(M, nfix=NFIX):
    """时间轴重采样到固定帧数 —— 消除长度/语速的绝对时长线索"""
    idx = np.linspace(0, M.shape[0] - 1, nfix).astype(int)
    return M[idx]

def add_noise(y, snr_db, rng):
    if snr_db is None: return y
    sp = np.mean(y ** 2); np_ = sp / (10 ** (snr_db / 10.0))
    return y + np.sqrt(np_) * rng.standard_normal(len(y))

def feats(seqs, K=KM):
    """固定帧数 -> 位置 one-hot + unigram 直方图 + 切换率 + 熵（不含长度）"""
    F = []
    for s in seqs:
        oh = np.zeros((NFIX, K)); oh[np.arange(NFIX), s] = 1.0
        h = np.bincount(s, minlength=K).astype(float); h /= (h.sum() + 1e-9)
        sw = float(np.mean(s[1:] != s[:-1]))
        ent = float(-(h[h > 0] * np.log(h[h > 0])).sum()) / math.log(K)
        F.append(np.concatenate([oh.ravel(), h, [sw, ent]]))
    return np.array(F)

def cv_acc(F, y, seed=0, folds=5):
    clf = RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=-1)
    sk = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    return float(cross_val_score(clf, F, y, cv=sk).mean())

def boot_ci(F, y, B=10, seed=0):
    """配对 bootstrap：判断帧率差异是否真显著（吸取 055/069b 教训）"""
    rng = np.random.default_rng(seed); accs = []
    n = len(y)
    for b in range(B):
        idx = rng.integers(0, n, n)
        if len(set(y[idx].tolist())) < 2: continue
        accs.append(_quick_acc(F[idx], y[idx]))
    a = np.array(accs)
    return float(np.percentile(a, 2.5)), float(np.percentile(a, 97.5))

def _quick_acc(F, y):
    from sklearn.model_selection import cross_val_score
    clf = RandomForestClassifier(n_estimators=50, random_state=0, n_jobs=-1)
    sk = StratifiedKFold(n_splits=3, shuffle=True, random_state=1)
    return float(cross_val_score(clf, F, y, cv=sk).mean())

def main():
    N_PER = 16
    ys, y = [], []
    for li, st in enumerate(LABELS):
        for j in range(N_PER):
            ys.append(synth(st, 1000 + li * 100 + j)); y.append(li)
    y = np.array(y)
    print(f"[data] n={len(ys)}  每类{N_PER}  随机基线=0.25")

    # sanity：确认韵律差异进了波形（防静默失效）；注意时长差异已被重采样消除
    san = {}
    for i, L in enumerate(LABELS):
        sub = [ys[k] for k in range(len(ys)) if y[k] == i]
        san[L] = dict(rms=round(float(np.mean([np.sqrt(np.mean(v**2)) for v in sub])), 4),
                      raw_dur_s=round(float(np.mean([len(v)/SR for v in sub])), 3))
    print("[sanity]", json.dumps(san, ensure_ascii=False))

    RATES = [6.25, 12.5, 25.0, 50.0]
    SNRS = [None, 20.0, 10.0, 5.0, 0.0]
    grid = {}
    print("\n=== H3: 帧率 x SNR 网格（固定16帧，长度线索已消除）===")
    for snr in SNRS:
        rng = np.random.default_rng(7)
        ysn = [add_noise(v, snr, np.random.default_rng(11 + k)) for k, v in enumerate(ys)]
        row = {}
        for rate in RATES:
            Mraw = [stft_mel(v) for v in ysn]
            # 先在 100Hz 上做时间平均到目标帧率，再重采样到固定 16 帧
            k = int(round(100.0 / rate))
            Mp = []
            for M in Mraw:
                n = (M.shape[0] // k) * k
                Mp.append(resample_frames(M[:n].reshape(n // k, k, M.shape[1]).mean(1)) if n else resample_frames(M))
            allf = np.vstack(Mp)
            km = KMeans(n_clusters=KM, n_init=10, random_state=0).fit(allf)
            seqs = [km.predict(m) for m in Mp]
            F = feats(seqs)
            acc = cv_acc(F, y)
            lo, hi = boot_ci(F, y) if (snr in (None, 10.0)) else (acc, acc)
            # 对照：打乱位置（保留直方图，破坏时序）
            r2 = np.random.default_rng(0)
            Fsh = feats([s[r2.permutation(len(s))] for s in seqs])
            acc_sh = cv_acc(Fsh, y)
            row[str(rate)] = dict(acc=round(acc, 4), ci=[round(lo,4), round(hi,4)], acc_shuffled=round(acc_sh, 4))
            print(f"  SNR={str(snr):>5}  rate={rate:>5}Hz  acc={acc:.4f} CI[{lo:.3f},{hi:.3f}]  位置打乱={acc_sh:.4f}")
        grid['clean' if snr is None else f"{snr}dB"] = row

    # H1/H2：文本通道（按构造，所有样本同一句话）
    text_seqs = [np.array([0, 1, 2, 3, 4]) for _ in ys]
    uniq = len(set(tuple(t) for t in text_seqs))
    F_text = np.repeat(feats([np.array([0]*NFIX)]) , len(ys), axis=0)   # 恒同
    acc_text = cv_acc(F_text, y)
    print(f"\n=== H1/H2 ===  文本 token 唯一样本数={uniq}  acc={acc_text:.4f}  (随机=0.25)")

    # 引擎接入：音频 token 流 vs 文本 token 流 -> 内在结构
    from core import Life5
    def run_life(sal_vec, seed):
        lf = Life5(N=len(sal_vec), seed=seed, k_sal=0.45, sal=np.asarray(sal_vec, float))
        for _ in range(600): lf.step()
        cap = np.asarray(lf.capacity, float)
        return float(np.std(cap) / (np.mean(cap) + 1e-12)), bool(np.all(cap > 1e-6))
    Mraw = [stft_mel(v) for v in ys]
    k = 8  # 12.5Hz
    Mp = []
    for M in Mraw:
        n = (M.shape[0] // k) * k
        Mp.append(resample_frames(M[:n].reshape(n // k, k, M.shape[1]).mean(1)))
    km12 = KMeans(n_clusters=KM, n_init=10, random_state=0).fit(np.vstack(Mp))
    seqs12 = [km12.predict(m) for m in Mp]
    sk_a, sk_t, alive = [], [], 0
    for i in range(len(ys)):
        sa = np.bincount(seqs12[i], minlength=KM).astype(float)[:8]; sa /= (sa.sum() + 1e-9)
        stx = np.full(8, 1/8)                                # 文本通道：恒同，零信息
        a, al = run_life(sa, seed=i); t, _ = run_life(stx, seed=i)
        sk_a.append(a); sk_t.append(t); alive += int(al)
    print(f"[引擎] 音频token流 skew={np.mean(sk_a):.4f}   文本token流(恒同) skew={np.mean(sk_t):.4f}   存活={alive}/{len(ys)}")

    out = dict(timestamp=__import__('time').strftime("%Y-%m-%d %H:%M:%S"),
        sanity=san, grid=grid,
        text_channel=dict(acc=round(acc_text,4), unique_sequences=int(uniq), chance=0.25),
        engine=dict(skew_audio=round(float(np.mean(sk_a)),4), skew_text=round(float(np.mean(sk_t)),4), alive=f"{alive}/{len(ys)}"),
        bug_v1="v1 acc=1.0000 饱和：序列长度进了特征 + 四类时长不同 -> 长度一击必杀；v2 固定16帧已消除",
        source_convergence=dict(
            Qwen3_Omni="AuT 12.5Hz 连续 audio hidden states，与 text token 拼接进 Thinker",
            Moshi_Mimi="24kHz -> 12.5Hz x 8 码本离散 codec token，双流 + inner monologue",
            Kimi_Audio="Whisper encoder 内插 VQ -> 12.5Hz 离散语义 token + 连续声学向量，双头",
            GLM4_Voice="Whisper encoder 插 VQ 层 -> 离散 token"))
    p = os.path.join(ROOT, 'experiments', 'result_083.json')
    json.dump(out, open(p, 'w'), ensure_ascii=False, indent=2)
    print("[saved]", p)

if __name__ == '__main__':
    main()
