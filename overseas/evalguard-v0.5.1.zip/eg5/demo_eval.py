
def score(golds, hits):
    try:
        return hits / len(golds)
    except:
        pass
for i in range(3):
    acc = score([], 5)
print("accuracy", acc)
